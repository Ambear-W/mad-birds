﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class damageControl : MonoBehaviour{
    public int health = 2;
    public float damangeImpactSpeed;
    public Sprite damagedSprite;

    private int currentHP;
    private float damangeImpactSpeedSqr;
    private SpriteRenderer spriteRenderer;

    // Start is called before the first frame update
    void Start(){
        spriteRenderer = GetComponent<SpriteRenderer>();
        currentHP = health;
        damangeImpactSpeedSqr = damangeImpactSpeed * damangeImpactSpeed;
    }

    // Update is called once per frame
    void OnCollisionEnter2D(Collision2D collision){
        if (collision.collider.tag != "Damager")
            return;
        if (collision.relativeVelocity.sqrMagnitude < damangeImpactSpeedSqr)
            return;

        spriteRenderer.sprite = damagedSprite;
        currentHP--;

        if(currentHP <= 0) 
            Kill();
    }

    void Kill(){
        spriteRenderer.enabled = false;
        GetComponent<Collider2D>().enabled = false;
        GetComponent<Rigidbody2D>().isKinematic = true;

        GetComponent<ParticleSystem>().Play();
    }
}
